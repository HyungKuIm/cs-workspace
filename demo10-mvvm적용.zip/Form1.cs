using demo10.Models;
using System;
using System.Windows.Forms;

namespace demo10
{
    public partial class Form1 : Form
    {
        private readonly ITodoRepository todoRepository;
        public Form1()
        {
            InitializeComponent();
            todoRepository = new TodoRepositoryXml(@"g:\tmp\todos.xml");
            this.Load += Form1_Load;
            this.btnAdd.Click += BtnAdd_Click;
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            string title = txtTitle.Text;
            bool isDone = blnIsDone.Checked;

            var todo = new Todo { Title = title, IsDone = isDone };

            todoRepository.Add(todo);

            DisplayData();

        }

        private void Form1_Load(object sender, System.EventArgs e)
        {
            DisplayData();
        }

        private void DisplayData()
        {
            todoRepository.GetAll();
            this.dataGridView1.DataSource = null;
            this.dataGridView1.DataSource = todoRepository.Todos;
        }
    }
}
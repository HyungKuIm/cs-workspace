using System;
using System.Xml;

namespace demo10
{
    class ReadCnnWorldXml
    {
        static void main()
        {
            string url = "http://rss.cnn.com/rss/edition_world.rss";
            XmlDocument xml = new XmlDocument();
            xml.Load(url);
            string xpath = "//rss/channel/item";
            XmlNodeList nodes = xml.SelectNodes(xpath);
            foreach (XmlNode node in nodes)
            {
                var tNode = node.SelectSingleNode("title");
                var dNode = node.SelectSingleNode("pubDate");
                System.Console.WriteLine($"{tNode?.InnerText} - {dNode?.InnerText}");
            }
            
        }
    }
}
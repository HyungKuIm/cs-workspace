using System;

namespace demo8
{
    class FormatPriceInterpolatedVerbatim
    {
        static void main(string[] args)
        {
            decimal price = 769000m;
            decimal tip = price * 0.2m;
            Console.WriteLine($@"Price: {price,9:C}
Tip: {tip,9:C}
Total: {price + tip,9:C}");
        }
    }
}

using System;
using System.Globalization;
using System.Runtime.CompilerServices;
using static System.FormattableString;

namespace demo8
{
    class FormatDateInvariant
    {
        static void main()
        {

            //FormattableString
            var dateOfBirth = new DateTime(1966, 10, 6);
            FormattableString formattableString = 
                $"Hong was born on {dateOfBirth:d}";
            var culture = CultureInfo.GetCultureInfo("ja-JP");  // 일본 ko-KR 한국     
            var result = formattableString.ToString(culture);
            System.Console.WriteLine(result);


            int x = 10;
            int y = 20;
            FormattableString formattable = $"x = {x}, y={y}";
            FormattableString formattable1 = FormattableStringFactory.Create("x = {0}, y = {1}", x, y);

            System.Console.WriteLine(formattable.ToString());
            System.Console.WriteLine(formattable1.ToString());

            DateTime date = DateTime.UtcNow;

            string parameter1 = string.Format(
                CultureInfo.InvariantCulture,
                "x={0:yyyy-MM-dd}",
                date);
            System.Console.WriteLine(parameter1);

            string parameter2 = ((FormattableString)$"x={date:yyyy-MM-dd}").ToString(CultureInfo.InvariantCulture);

            string parameter3 = FormattableString.Invariant($"x={date:yyyy-MM-dd}");

            string parameter4 = Invariant($"x={date:yyyy-MM-dd}");

            System.Console.WriteLine($"{parameter2} {parameter3} {parameter4}");
        }
    }
}
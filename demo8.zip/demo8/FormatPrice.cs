using System;

namespace demo8
{
    class FormatPrice
    {
        static void main(string[] args)
        {
            decimal price = 769000m;
            decimal tip = price * 0.2m;
            Console.WriteLine("Price: {0,9:C}", price);
            Console.WriteLine("Tip: {0,9:C}", tip);
            Console.WriteLine("Total: {0,9:C}", price + tip);
        }
    }
}

﻿using System;

namespace demo8
{
    class Program
    {
        static void main(string[] args)
        {
            Console.Write("당신의 이름은?");
            string name = Console.ReadLine();
            Console.WriteLine("안녕하세요, {0}님!", name);
        }
    }
}

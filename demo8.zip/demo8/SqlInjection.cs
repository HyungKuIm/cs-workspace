using System;
using System.Data.OleDb;
namespace demo8
{
    class SqlInjection
    {
        static void Main()
        {
            var connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\a\Documents\SampleDB.accdb";
            Console.Write("부서 코드를 입력하세요?");
            var deptCode = Console.ReadLine();
            using (var cn = new OleDbConnection(connectionString))
            {
                cn.Open();
                string sql = $@"SELECT * FROM 사원
                                WHERE 부서코드 = '{deptCode}'";
                using (var cmd = new OleDbCommand(sql, cn))
                {
                    using (var dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            Console.WriteLine($"{dr[0]}:{dr[1]}");
                        }
                    }        
                }
            }
        }
    }
}
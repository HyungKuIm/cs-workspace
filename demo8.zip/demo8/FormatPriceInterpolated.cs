using System;

namespace demo8
{
    class FormatPriceInterpolated
    {
        static void main(string[] args)
        {
            decimal price = 769000m;
            decimal tip = price * 0.2m;
            Console.WriteLine($"Price: {price,9:C}");
            Console.WriteLine($"Tip: {tip,9:C}");
            Console.WriteLine($"Total: {price + tip,9:C}");
        }
    }
}

using System;

namespace demo8
{
    class EagerEvaluation
    {
        static void main()
        {
            string value = "유재석";
            //int alignment = 9;
            Console.WriteLine($"무한도전: {value, 9}");

            value = "정현돈";
            Console.WriteLine($"무한도전: {value, 9}");

            FormattableString formattable = $"무한도전: {value, 9}";
            Console.WriteLine(formattable);

            value = "유재석";
            Console.WriteLine(formattable);

            // 삼항 연산자 사용시 주의사항
            int age = 45;
            //System.Console.WriteLine($"Adult? {age >= 19 ? "Yes" : "No"}");
            System.Console.WriteLine($"Adult? {(age >= 19 ? "Yes" : "No")}");
        }
    }
}
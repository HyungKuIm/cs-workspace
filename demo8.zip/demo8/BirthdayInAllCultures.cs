using System;
using System.Globalization;

namespace demo8
{
    class BirthdayInAllCultures
    {
        static void main()
        {
            var cultures = CultureInfo.GetCultures(CultureTypes.AllCultures);
            var birthDate = new DateTime(1966, 10, 6);
            foreach (var culture in cultures)
            {
                string text = string.Format(culture, "{0,-15} {1,12:d}", culture.Name, birthDate);
                Console.WriteLine(text);
            }
        }
    }
}
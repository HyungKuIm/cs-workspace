using System;
using System.Xml;

namespace demo10
{
    class ReadEuroXml
    {
        static void main()
        {
            string url = "https://www.ecb.europa.eu/stats/eurofxref/eurofxref-daily.xml";

            XmlDocument xml = new XmlDocument();
            xml.Load(url);

            foreach (XmlNode xmlNode in xml.DocumentElement.ChildNodes[2].ChildNodes[0].ChildNodes) 
            {
                Console.WriteLine(xmlNode.Attributes["currency"].Value + ": " + xmlNode.Attributes["rate"].Value);
            }
        }
    }
}
using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using demo10.Models;


namespace demo10
{
    class MainViewModel : INotifyPropertyChanged
    {
        private readonly ITodoRepository todoRepository;
        public MainViewModel(ITodoRepository todoRepository)
        {
           this.todoRepository = todoRepository;
           List<Todo> todoList = this.todoRepository.GetAll();
           this.Todos = new ObservableCollection<Todo>(todoList);
        }

        public ObservableCollection<Todo> Todos { get; private set;}

        public void Add(Todo todo)
        {
            this.todoRepository.Add(todo);
            //this.Todos = new ObservableCollection<Todo>(this.todoRepository.GetAll());
            //재조회
            //NotifyPropertyChanged("Todos");

        }

        public void GetAllTodos() 
        {
            List<Todo> todoList = this.todoRepository.GetAll();
            this.Todos = new ObservableCollection<Todo>(todoList);
        }

        public event PropertyChangedEventHandler PropertyChanged;

        private void NotifyPropertyChanged([CallerMemberName] string propertyName = null)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
        
        
    }
}
using System;
using System.Xml;

namespace demo10
{
    class UserAge
    {
        static void main()
        {
            XmlDocument xml = new XmlDocument();
            var users = new[] {
                new {Name = "Jung Ho Kang", Age = 35},
                new {Name = "Lee Jung-hoo", Age = 24}
            };

            XmlNode rootNode = xml.CreateElement("users");
            xml.AppendChild(rootNode);

            foreach (var user in users)
            {
                XmlNode userNode = xml.CreateElement("user");
                XmlAttribute ageAttr = xml.CreateAttribute("age");
                ageAttr.Value = user.Age.ToString();
                userNode.Attributes.Append(ageAttr);
                userNode.InnerText = user.Name;
                rootNode.AppendChild(userNode);
            }

            xml.Save("text-doc.xml");
        }
    }
}
using System;
using System.Xml;

namespace demo10
{
    class ReadMovieXml
    {
        static void main()
        {
            string xmlFilepath = @"movies.xml";

            XmlDocument xml = new XmlDocument();
            xml.Load(xmlFilepath);

            string xpath01 = @"//Movies/Movie";
            XmlNodeList nodes = xml.SelectNodes(xpath01);
            foreach (XmlNode node in nodes)
            {
                string xpath02 = @"Director/Name";
                XmlNode aNode = node.SelectSingleNode(xpath02);

                string a = aNode.InnerText;

                System.Console.WriteLine(a);
            }
        }
    }
}